package com.techinnovator.jmnewsapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;

public class MySingleton {
}